exports.id = 6004;
exports.ids = [6004];
exports.modules = {

/***/ 5335:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _redux_constants_actionTypes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5227);
/* harmony import */ var _util_localStorage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1365);





const saveStoredItems = (storedItems)=>(dispatch)=>{
        dispatch({
            type: _redux_constants_actionTypes__WEBPACK_IMPORTED_MODULE_3__/* .INIT_LOCALSTORAGE */ .Y7,
            payload: {
                ...storedItems
            }
        });
    };
const StorageWrapper = (props)=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const cart = _util_localStorage__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.get("dokani_cart") || [];
        const wishlist = _util_localStorage__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.get("dokani_wishlist") || [];
        const compare = _util_localStorage__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.get("dokani_compare") || [];
        props.saveStoredItems({
            cart,
            wishlist,
            compare
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: props.children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)(null, {
    saveStoredItems
})(StorageWrapper));


/***/ }),

/***/ 8070:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Preloader = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "preloader-active",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "preloader d-flex align-items-center justify-content-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "preloader-inner position-relative",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "mb-5",
                                children: "Now Loading"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "loader",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "bar bar1"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "bar bar2"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "bar bar3"
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Preloader);


/***/ }),

/***/ 6004:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react_perfect_scrollbar_dist_css_styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4103);
/* harmony import */ var react_perfect_scrollbar_dist_css_styles_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_perfect_scrollbar_dist_css_styles_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_responsive_modal_styles_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4602);
/* harmony import */ var react_responsive_modal_styles_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_responsive_modal_styles_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7310);
/* harmony import */ var _components_ecommerce_storage_wrapper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5335);
/* harmony import */ var _public_assets_css_main_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8195);
/* harmony import */ var _public_assets_css_main_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_public_assets_css_main_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3590);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_elements_Preloader__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8070);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_9__]);
react_toastify__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










// Swiper Slider




function MyApp({ Component, pageProps }) {
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        setLoading(true);
        setTimeout(()=>{
            setLoading(false);
        }, 2000);
        if (false) {}
        new WOW.WOW().init();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: !loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_2__.Provider, {
            store: _redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ecommerce_storage_wrapper__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_9__.ToastContainer, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    })
                ]
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Preloader__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $J: () => (/* binding */ UPDATE_PRODUCT_CATEGORY),
/* harmony export */   Cm: () => (/* binding */ ADD_TO_WISHLIST),
/* harmony export */   Cr: () => (/* binding */ UPDATE_RATING),
/* harmony export */   DZ: () => (/* binding */ CLOSE_WISHLIST),
/* harmony export */   G2: () => (/* binding */ ADD_TO_CART),
/* harmony export */   GS: () => (/* binding */ OPEN_QUICK_VIEW),
/* harmony export */   Jx: () => (/* binding */ CLEAR_COMPARE),
/* harmony export */   Oh: () => (/* binding */ DELETE_FROM_COMPARE),
/* harmony export */   Q7: () => (/* binding */ UPDATE_PRODUCT),
/* harmony export */   R3: () => (/* binding */ OPEN_WISHLIST),
/* harmony export */   RC: () => (/* binding */ INCREASE_QUANTITY),
/* harmony export */   Wi: () => (/* binding */ UPDATE_PRODUCT_FILTERS),
/* harmony export */   Y7: () => (/* binding */ INIT_LOCALSTORAGE),
/* harmony export */   Yw: () => (/* binding */ DELETE_FROM_CART),
/* harmony export */   Zd: () => (/* binding */ ADD_TO_COMPARE),
/* harmony export */   eL: () => (/* binding */ DECREASE_QUANTITY),
/* harmony export */   fJ: () => (/* binding */ CLOSE_QUICK_VIEW),
/* harmony export */   jP: () => (/* binding */ FETCHED_PRODUCT),
/* harmony export */   l2: () => (/* binding */ FETCHED_MORE_PRODUCT),
/* harmony export */   lS: () => (/* binding */ CLEAR_WISHLIST),
/* harmony export */   qX: () => (/* binding */ CLEAR_CART),
/* harmony export */   tN: () => (/* binding */ OPEN_CART),
/* harmony export */   u7: () => (/* binding */ DELETE_PRODUCT),
/* harmony export */   ww: () => (/* binding */ DELETE_FROM_WISHLIST),
/* harmony export */   wy: () => (/* binding */ CLOSE_CART),
/* harmony export */   y1: () => (/* binding */ OPEN_COMPARE),
/* harmony export */   zN: () => (/* binding */ ADD_PRODUCT),
/* harmony export */   zg: () => (/* binding */ CLOSE_COMPARE)
/* harmony export */ });
/* unused harmony exports OPEN_LOGIN_MODAL, CLOSE_LOGIN_MODAL */
// PRODUCT TYPES
const ADD_PRODUCT = "ADD_PRODUCT";
const DELETE_PRODUCT = "DELETE_PRODUCT";
const UPDATE_PRODUCT = "UPDATE_PRODUCT";
const FETCHED_PRODUCT = "FETCHED_PRODUCT";
const FETCHED_MORE_PRODUCT = "FETCHED_MORE_PRODUCT";
// CART TYPES
const ADD_TO_CART = "ADD_TO_CART";
const DELETE_FROM_CART = "DELETE_FROM_CART";
const INCREASE_QUANTITY = "INCREASE_QUANTITY";
const DECREASE_QUANTITY = "DECREASE_QUANTITY";
const OPEN_CART = "OPEN_CART";
const CLOSE_CART = "CLOSE_CART";
const CLEAR_CART = "CLEAR_CART";
// WISHLIST TYPES
const ADD_TO_WISHLIST = "ADD_TO_WISHLIST";
const DELETE_FROM_WISHLIST = "DELETE_FROM_WISHLIST";
const OPEN_WISHLIST = "OPEN_WISHLIST";
const CLOSE_WISHLIST = "CLOSE_WISHLIST";
const CLEAR_WISHLIST = "CLEAR_WISHLIST";
// COMPARE TYPES
const ADD_TO_COMPARE = "ADD_TO_COMPARE";
const DELETE_FROM_COMPARE = "DELETE_FROM_COMPARE";
const OPEN_COMPARE = "OPEN_COMPARE";
const CLOSE_COMPARE = "CLOSE_COMPARE";
const CLEAR_COMPARE = "CLEAR_COMPARE";
// QUICK VIEW TYPES
const OPEN_QUICK_VIEW = "OPEN_QUICK_VIEW";
const CLOSE_QUICK_VIEW = "CLOSE_QUICK_VIEW";
// FILTERS TYPES
const UPDATE_PRODUCT_FILTERS = "UPDATE_PRODUCT_FILTERS";
const UPDATE_PRODUCT_CATEGORY = "UPDATE_PRODUCT_CATEGORY";
const UPDATE_RATING = "UPDATE_RATING";
//  LOGIN MODAL
const OPEN_LOGIN_MODAL = "OPEN_LOGIN_MODAL";
const CLOSE_LOGIN_MODAL = "CLOSE_LOGIN_MODAL";
// LOCAL STORAGE
const INIT_LOCALSTORAGE = "INIT_LOCALSTORAGE";


/***/ }),

/***/ 7310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ redux_store)
});

// EXTERNAL MODULE: external "redux"
var external_redux_ = __webpack_require__(6695);
// EXTERNAL MODULE: external "redux-devtools-extension"
var external_redux_devtools_extension_ = __webpack_require__(173);
// EXTERNAL MODULE: external "redux-thunk"
var external_redux_thunk_ = __webpack_require__(8417);
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_);
// EXTERNAL MODULE: ./util/util.js
var util = __webpack_require__(6937);
// EXTERNAL MODULE: ./redux/constants/actionTypes.js
var actionTypes = __webpack_require__(5227);
;// CONCATENATED MODULE: ./redux/reducer/product.js


// {items:[],filteredList:[]}
/* harmony default export */ const product = ((state = {
    items: []
}, action)=>{
    switch(action.type){
        case actionTypes/* FETCHED_PRODUCT */.jP:
            return {
                ...state,
                items: [
                    ...action.payload.products
                ]
            };
        case actionTypes/* FETCHED_MORE_PRODUCT */.l2:
            const mergeAllProducts = [
                ...state.items,
                ...action.payload.products
            ];
            // console.log(mergeAllProducts);
            const limit = action.payload.total && mergeAllProducts.length > action.payload.total ? mergeAllProducts.splice(0, action.payload.total) : mergeAllProducts;
            return {
                ...state,
                items: [
                    ...limit
                ]
            };
        case actionTypes/* ADD_PRODUCT */.zN:
            return {
                ...state,
                items: [
                    ...state.items,
                    action.payload
                ]
            };
        case actionTypes/* DELETE_PRODUCT */.u7:
            return (0,util/* deleteProduct */.Ir)(state, action.payload.id);
        case actionTypes/* UPDATE_PRODUCT */.Q7:
            const index = (0,util/* findProductIndexById */.eQ)(state, action.payload.product.id);
            state[index] = action.payload.product;
            return {
                ...state
            };
        default:
            return state;
    }
});

// EXTERNAL MODULE: ./util/localStorage.js
var localStorage = __webpack_require__(1365);
;// CONCATENATED MODULE: ./redux/reducer/cart.js



/* harmony default export */ const cart = ((state = [], action)=>{
    let index = null;
    switch(action.type){
        case actionTypes/* INIT_LOCALSTORAGE */.Y7:
            return [
                ...action.payload.cart
            ];
        case actionTypes/* ADD_TO_CART */.G2:
            index = (0,util/* findProductIndexById */.eQ)(state, action.payload.product.id);
            if (index !== -1) {
                state[index].quantity += 1;
                localStorage/* default */.Z.set("dokani_cart", [
                    ...state
                ]);
                return [
                    ...state
                ];
            } else {
                if (!action.payload.product.quantity) {
                    action.payload.product.quantity = 1;
                }
                localStorage/* default */.Z.set("dokani_cart", [
                    ...state,
                    action.payload.product
                ]);
                return [
                    ...state,
                    action.payload.product
                ];
            }
        case actionTypes/* DELETE_FROM_CART */.Yw:
            const newCartItems = (0,util/* deleteProduct */.Ir)(state, action.payload.productId);
            localStorage/* default */.Z.set("dokani_cart", newCartItems);
            return [
                ...newCartItems
            ];
        case actionTypes/* INCREASE_QUANTITY */.RC:
            index = (0,util/* findProductIndexById */.eQ)(state, action.payload.productId);
            if (index === -1) return state;
            state[index].quantity += 1;
            localStorage/* default */.Z.set("dokani_cart", [
                ...state
            ]);
            return [
                ...state
            ];
        case actionTypes/* DECREASE_QUANTITY */.eL:
            index = (0,util/* findProductIndexById */.eQ)(state, action.payload.productId);
            if (index === -1) return state;
            const quantity = state[index].quantity;
            if (quantity > 1) state[index].quantity -= 1;
            localStorage/* default */.Z.set("dokani_cart", [
                ...state
            ]);
            return [
                ...state
            ];
        case actionTypes/* CLEAR_CART */.qX:
            localStorage/* default */.Z.set("dokani_cart", []);
            return [];
        default:
            return state;
    }
});

;// CONCATENATED MODULE: ./redux/reducer/wishlist.js



const initialState = {
    modal: false,
    items: []
};
/* harmony default export */ const wishlist = ((state = initialState, action)=>{
    let index = null;
    switch(action.type){
        case actionTypes/* OPEN_WISHLIST */.R3:
            return {
                ...state,
                modal: true
            };
        case actionTypes/* CLOSE_WISHLIST */.DZ:
            return {
                ...state,
                modal: false
            };
        case actionTypes/* INIT_LOCALSTORAGE */.Y7:
            return {
                ...state,
                items: [
                    ...action.payload.wishlist
                ]
            };
        case actionTypes/* ADD_TO_WISHLIST */.Cm:
            index = (0,util/* findProductIndexById */.eQ)(state.items, action.payload.product.id);
            if (index !== -1) return state;
            const items = [
                ...state.items,
                action.payload.product
            ];
            localStorage/* default */.Z.set("dokani_wishlist", items);
            return {
                ...state,
                items
            };
        case actionTypes/* DELETE_FROM_WISHLIST */.ww:
            const list = (0,util/* deleteProduct */.Ir)(state.items, action.payload.productId);
            localStorage/* default */.Z.set("dokani_wishlist", list);
            return {
                ...state,
                items: [
                    ...list
                ]
            };
        case actionTypes/* CLEAR_WISHLIST */.lS:
            localStorage/* default */.Z.set("dokani_wishlist", []);
            return {
                ...state,
                items: []
            };
        default:
            return state;
    }
});

;// CONCATENATED MODULE: ./redux/reducer/quickView.js

/* harmony default export */ const quickView = ((state = null, action)=>{
    switch(action.type){
        case actionTypes/* OPEN_QUICK_VIEW */.GS:
            console.log("quickview active");
            return {
                ...action.payload.product
            };
        case actionTypes/* CLOSE_QUICK_VIEW */.fJ:
            console.log("quickview close");
            return null;
        default:
            return state;
    }
});

;// CONCATENATED MODULE: ./redux/reducer/compare.js



const compare_initialState = {
    modal: false,
    items: []
};
/* harmony default export */ const compare = ((state = compare_initialState, action)=>{
    let index = null;
    switch(action.type){
        case actionTypes/* OPEN_COMPARE */.y1:
            return {
                ...state,
                modal: true
            };
        case actionTypes/* CLOSE_COMPARE */.zg:
            return {
                ...state,
                modal: false
            };
        case actionTypes/* INIT_LOCALSTORAGE */.Y7:
            return {
                ...state,
                items: [
                    ...action.payload.compare
                ]
            };
        case actionTypes/* ADD_TO_COMPARE */.Zd:
            index = (0,util/* findProductIndexById */.eQ)(state.items, action.payload.product.id);
            if (index !== -1) return state;
            const items = [
                ...state.items,
                action.payload.product
            ];
            localStorage/* default */.Z.set("dokani_compare", items);
            return {
                ...state,
                items
            };
        case actionTypes/* DELETE_FROM_COMPARE */.Oh:
            const list = (0,util/* deleteProduct */.Ir)(state.items, action.payload.productId);
            localStorage/* default */.Z.set("dokani_compare", list);
            return {
                ...state,
                items: [
                    ...list
                ]
            };
        case actionTypes/* CLEAR_COMPARE */.Jx:
            localStorage/* default */.Z.set("dokani_compare", []);
            return {
                ...state,
                items: []
            };
        default:
            return state;
    }
});

;// CONCATENATED MODULE: ./redux/reducer/productFilters.js

/* harmony default export */ const productFilters = ((state = {
    category: ""
}, action)=>{
    switch(action.type){
        case actionTypes/* UPDATE_PRODUCT_FILTERS */.Wi:
            return {
                ...state,
                ...action.payload.productFilters
            };
        case actionTypes/* UPDATE_PRODUCT_CATEGORY */.$J:
            const { category } = action.payload;
            return {
                ...state,
                category
            };
        case actionTypes/* UPDATE_RATING */.Cr:
            const { rating } = action.payload;
            return {
                ...state,
                rating
            };
        default:
            return state;
    }
});

;// CONCATENATED MODULE: ./redux/reducer/rootReducer.js







const rootReducer = (0,external_redux_.combineReducers)({
    products: product,
    cart: cart,
    wishlist: wishlist,
    quickView: quickView,
    compare: compare,
    productFilters: productFilters
});
/* harmony default export */ const reducer_rootReducer = (rootReducer);

;// CONCATENATED MODULE: ./redux/store.js




const store = (0,external_redux_.createStore)(reducer_rootReducer, (0,external_redux_devtools_extension_.composeWithDevTools)((0,external_redux_.applyMiddleware)((external_redux_thunk_default()))));
/* harmony default export */ const redux_store = (store);


/***/ }),

/***/ 1365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
class storage {
    static set(key, cartItems) {
        localStorage.setItem(key, JSON.stringify(cartItems));
    }
    static get(key) {
        return JSON.parse(localStorage.getItem(key));
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (storage);


/***/ }),

/***/ 6937:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ir: () => (/* binding */ deleteProduct),
/* harmony export */   eQ: () => (/* binding */ findProductIndexById),
/* harmony export */   wC: () => (/* binding */ findProductIndex)
/* harmony export */ });
// Delete Product from List By Id
const deleteProduct = (list, id)=>{
    const filter = list.filter((item)=>item.id !== id);
    return filter;
};
// Find Product Index From List
const findProductIndex = (list, slug)=>{
    const index = list.findIndex((item)=>item.slug === slug);
    return index;
};
const findProductIndexById = (list, id)=>{
    const index = list.findIndex((item)=>item.id === id);
    return index;
};


/***/ }),

/***/ 8195:
/***/ (() => {



/***/ })

};
;