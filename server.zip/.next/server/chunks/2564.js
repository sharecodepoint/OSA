"use strict";
exports.id = 2564;
exports.ids = [2564];
exports.modules = {

/***/ 2564:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ layout_Layout)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/layout/Breadcrumb.js


const Breadcrumb = ({ parent, sub, subChild, noBreadcrumb })=>{
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: `page-header breadcrumb-wrap ${noBreadcrumb}`,
            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "breadcrumb",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                children: parent
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("span", {}),
                        " ",
                        sub,
                        /*#__PURE__*/ jsx_runtime.jsx("span", {}),
                        " ",
                        subChild
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const layout_Breadcrumb = (Breadcrumb);

;// CONCATENATED MODULE: ./components/layout/Footer.js



const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("footer", {
            className: "main",
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("section", {
                    className: "newsletter p-30 mt-30 text-white wow fadeIn animated"
                }),
                /*#__PURE__*/ jsx_runtime.jsx("section", {
                    className: "section-padding footer-mid",
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "container pt-15 pb-20",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "col-lg-5 col-md-6",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "widget-about font-md mb-md-5 mb-lg-0",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "logo logo-width-1 wow fadeIn animated",
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                            src: "/assets/imgs/theme/logo.svg",
                                                            alt: "logo"
                                                        })
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                                className: "mt-20 mb-10 fw-600 text-grey-4 wow fadeIn animated",
                                                children: "Contact"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                className: "wow fadeIn animated",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                                        children: "Address: "
                                                    }),
                                                    "Urban Estate, 555, Golf Course Rd, Sector 43, Gurugram, Haryana 122001"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                className: "wow fadeIn animated",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                                        children: "Phone: "
                                                    }),
                                                    "+(+91) 70 1125 8995 /(+91) 01 2345 6789"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                className: "wow fadeIn animated",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                                        children: "Hours: "
                                                    }),
                                                    "10:00 - 18:00, Mon - Sat"
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "col-lg-3 col-md-3",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                            className: "widget-title wow fadeIn animated",
                                            children: "Quick Links"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                            className: "footer-list wow fadeIn animated mb-sm-5 mb-md-0",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "#",
                                                        children: "About Us"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "#",
                                                        children: "Privacy Policy"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "#",
                                                        children: "Terms & Conditions"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "col-lg-3 col-md-3",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                            className: "mb-10 mt-30 fw-600 text-grey-4 wow fadeIn animated",
                                            children: "Follow Us"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "mobile-social-icon wow fadeIn animated mb-sm-5 mb-md-0",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                        src: "/assets/imgs/theme/icons/icon-facebook.svg",
                                                        alt: ""
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                        src: "/assets/imgs/theme/icons/icon-twitter.svg",
                                                        alt: ""
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                        src: "/assets/imgs/theme/icons/icon-instagram.svg",
                                                        alt: ""
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                        src: "/assets/imgs/theme/icons/icon-pinterest.svg",
                                                        alt: ""
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "#",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                        src: "/assets/imgs/theme/icons/icon-youtube.svg",
                                                        alt: ""
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "container pb-20 wow fadeIn animated",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "col-12 mb-20",
                                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "footer-bottom"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "col-lg-6",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                    className: "float-md-left font-sm text-muted mb-0",
                                    children: [
                                        "\xa9 ",
                                        new Date().getFullYear(),
                                        ",",
                                        /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                            className: "text-brand",
                                            children: " AV"
                                        }),
                                        " - Example"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "col-lg-6",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                    className: "text-lg-end text-start font-sm text-muted mb-0",
                                    children: [
                                        "Designed by",
                                        /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: "https://crm.coderxpoint.com/login",
                                            target: "_blank",
                                            children: " CoderXpoint"
                                        }),
                                        ". All rights reserved"
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const layout_Footer = (Footer);

// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/ecommerce/Search.js



const Search = ()=>{
    const [searchTerm, setSearchTerm] = (0,external_react_.useState)("");
    const router = (0,router_.useRouter)();
    const handleSearch = ()=>{
        console.log("click");
        router.push({
            pathname: "/products",
            query: {
                search: searchTerm
            }
        });
        setSearchTerm("");
    };
    const handleInput = (e)=>{
        if (e.key === "Enter") {
            e.preventDefault();
            handleSearch();
        }
    };
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("form", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                    className: "select-active",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "All Categories"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "Women's"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "Men's"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "Cellphones"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "Computer"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "Electronics"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: " Accessories"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "Home & Garden"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "Luggage"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "Shoes"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                            children: "Mother & Kids"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime.jsx("input", {
                    value: searchTerm,
                    onKeyDown: handleInput,
                    onChange: (e)=>setSearchTerm(e.target.value),
                    type: "text",
                    placeholder: "Search"
                })
            ]
        })
    });
};
/* harmony default export */ const ecommerce_Search = (Search);

;// CONCATENATED MODULE: ./components/layout/Header.js





const Header = ({ totalCartItems, totalCompareItems, toggleClick, totalWishlistItems, headerStyle })=>{
    const [isToggled, setToggled] = (0,external_react_.useState)(false);
    const [scroll, setScroll] = (0,external_react_.useState)(0);
    (0,external_react_.useEffect)(()=>{
        document.addEventListener("scroll", ()=>{
            const scrollCheck = window.scrollY >= 100;
            if (scrollCheck !== scroll) {
                setScroll(scrollCheck);
            }
        });
    });
    const handleToggle = ()=>setToggled(!isToggled);
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("header", {
            className: `header-area ${headerStyle} header-height-2`,
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "header-middle header-middle-ptb-1 d-none d-lg-block",
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "header-wrap",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "logo logo-width-1",
                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                src: "/assets/imgs/theme/logo.svg",
                                                alt: "logo"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "header-right",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            className: "search-style-2",
                                            children: /*#__PURE__*/ jsx_runtime.jsx(ecommerce_Search, {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            className: "header-action-right",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "header-action-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        className: "header-action-icon-2",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/shop-compare",
                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                                        className: "svgInject",
                                                                        alt: "CoderXpoint",
                                                                        src: "/assets/imgs/theme/icons/icon-compare.svg"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                        className: "pro-count blue",
                                                                        children: totalCompareItems
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        className: "header-action-icon-2",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/shop-wishlist",
                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                                        className: "svgInject",
                                                                        alt: "CoderXpoint",
                                                                        src: "/assets/imgs/theme/icons/icon-heart.svg"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                        className: "pro-count blue",
                                                                        children: totalWishlistItems
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: scroll ? "header-bottom header-bottom-bg-color sticky-bar stick" : "header-bottom header-bottom-bg-color sticky-bar",
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "header-wrap header-space-between position-relative",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "logo logo-width-1 d-block d-lg-none",
                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                src: "/assets/imgs/theme/logo.svg",
                                                alt: "logo"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "header-nav d-none d-lg-flex",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "main-categori-wrap d-none d-lg-block",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                    className: "categori-button-active",
                                                    onClick: handleToggle,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "fi-rs-apps"
                                                        }),
                                                        "Products"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: isToggled ? "categori-dropdown-wrap categori-dropdown-active-large open" : "categori-dropdown-wrap categori-dropdown-active-large",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                className: "has-children",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/products",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                                    className: "CoderXpoint-font-dress"
                                                                                }),
                                                                                "Audio Visual Solutions"
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                        className: "dropdown-menu",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("ul", {
                                                                            className: "mega-menu d-lg-flex",
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                className: "mega-menu-col col-lg-12",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                                    className: "d-lg-flex",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            className: "mega-menu-col col-lg-6",
                                                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                                                            className: "submenu-title",
                                                                                                            children: "Connectivity Solutions"
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/products",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "AV Cables"
                                                                                                            })
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/products",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "Cable Managers"
                                                                                                            })
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/products",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "Faceplates"
                                                                                                            })
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/products",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "Floor Boxes"
                                                                                                            })
                                                                                                        })
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            className: "mega-menu-col col-lg-6",
                                                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                                                            className: "submenu-title",
                                                                                                            children: "Mounting Solutions"
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/#",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "Display Mount Brackets"
                                                                                                            })
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/#",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "Equiment Racks"
                                                                                                            })
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/#",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "Erogonomic Monitor Mounts"
                                                                                                            })
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/#",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "Floor Mount Trolleys"
                                                                                                            })
                                                                                                        })
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                className: "has-children",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/products",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                                    className: "CoderXpoint-font-tshirt"
                                                                                }),
                                                                                "Display Solutions"
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                        className: "dropdown-menu",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("ul", {
                                                                            className: "mega-menu d-lg-flex",
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                className: "mega-menu-col col-lg-12",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                                    className: "d-lg-flex",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            className: "mega-menu-col col-lg-6",
                                                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/#",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "Professional Displays"
                                                                                                            })
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                            href: "/#",
                                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                                className: "dropdown-item nav-link nav_item",
                                                                                                                children: "LED Displays"
                                                                                                            })
                                                                                                        })
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            className: "mega-menu-col col-lg-6",
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("ul", {
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                        href: "/#",
                                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                            className: "dropdown-item nav-link nav_item",
                                                                                                            children: "Interactive Displays"
                                                                                                        })
                                                                                                    })
                                                                                                })
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                    className: "more_slide_open",
                                                                    style: {
                                                                        display: "none"
                                                                    },
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                href: "/products",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                                            className: "CoderXpoint-font-desktop"
                                                                                        }),
                                                                                        "Beauty, Health"
                                                                                    ]
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                href: "/products",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                                            className: "CoderXpoint-font-cpu"
                                                                                        }),
                                                                                        "Bags and Shoes"
                                                                                    ]
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                href: "/products",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                                            className: "CoderXpoint-font-diamond"
                                                                                        }),
                                                                                        "Consumer Electronics"
                                                                                    ]
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                href: "/products",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                                            className: "CoderXpoint-font-home"
                                                                                        }),
                                                                                        "Automobiles & Motorcycles"
                                                                                    ]
                                                                                })
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            className: "main-menu main-menu-padding-1 main-menu-lh-2 d-none d-lg-block",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("nav", {
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/",
                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                    className: "active",
                                                                    children: "Home"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/page-about",
                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                    children: "About Us"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                            className: "position-static",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                    href: "/#",
                                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                        children: [
                                                                            "Products",
                                                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                                className: "fi-rs-angle-down"
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                    className: "mega-menu",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                            className: "sub-mega-menu sub-mega-menu-width-22",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                    href: "/#",
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                        className: "menu-title",
                                                                                        children: "Audio Visual Solutions"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Connectivity Solutions"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Mounting Solutions"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Projection Solutions"
                                                                                                })
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                            className: "sub-mega-menu sub-mega-menu-width-22",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                    href: "/#",
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                        className: "menu-title",
                                                                                        children: "Display Solutions"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Professional Displays"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Interactive Displays"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "LED Displays"
                                                                                                })
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                            className: "sub-mega-menu sub-mega-menu-width-22",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                    href: "/#",
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                        className: "menu-title",
                                                                                        children: "Technology"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Gaming Laptops"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Ultraslim Laptops"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Tablets"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Laptop Accessories"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Tablet Accessories"
                                                                                                })
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                            className: "sub-mega-menu sub-mega-menu-width-22",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                    href: "/#",
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                        className: "menu-title",
                                                                                        children: "Audio Visual Solutions"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Connectivity Solutions"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Mounting Solutions"
                                                                                                })
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                                href: "/products",
                                                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                                    children: "Projection Solutions"
                                                                                                })
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "#",
                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                    children: "Blog"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/page-contact",
                                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                    children: "Contact Us"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "header-action-right d-block d-lg-none",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "header-action-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "header-action-icon-2",
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/shop-wishlist",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                                alt: "CoderXpoint",
                                                                src: "/assets/imgs/theme/icons/icon-compare.svg"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                className: "pro-count white",
                                                                children: totalCompareItems
                                                            })
                                                        ]
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "header-action-icon-2",
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/shop-wishlist",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                                alt: "CoderXpoint",
                                                                src: "/assets/imgs/theme/icons/icon-heart.svg"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                className: "pro-count white",
                                                                children: totalWishlistItems
                                                            })
                                                        ]
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "header-action-icon-2",
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/shop-cart",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                        className: "mini-cart-icon",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                                alt: "CoderXpoint",
                                                                src: "/assets/imgs/theme/icons/icon-cart.svg"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                className: "pro-count white",
                                                                children: totalCartItems
                                                            })
                                                        ]
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "header-action-icon-2 d-block d-lg-none",
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "burger-icon burger-icon-white",
                                                    onClick: toggleClick,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "burger-icon-top"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "burger-icon-mid"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "burger-icon-bottom"
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};
const mapStateToProps = (state)=>({
        totalCartItems: state.cart.length,
        totalCompareItems: state.compare.items.length,
        totalWishlistItems: state.wishlist.items.length
    });
/* harmony default export */ const layout_Header = ((0,external_react_redux_.connect)(mapStateToProps, null)(Header));

;// CONCATENATED MODULE: ./util/outsideClick.js

const useClickOutside = (handler)=>{
    let domNode = (0,external_react_.useRef)();
    (0,external_react_.useEffect)(()=>{
        let maybeHandler = (event)=>{
            if (!domNode.current.contains(event.target)) {
                handler();
            }
        };
        document.addEventListener("mousedown", maybeHandler);
        return ()=>{
            document.removeEventListener("mousedown", maybeHandler);
        };
    });
    return domNode;
};
/* harmony default export */ const outsideClick = (useClickOutside);

;// CONCATENATED MODULE: ./components/layout/MobileMenu.js




const MobileMenu = ({ isToggled, toggleClick })=>{
    const [isActive, setIsActive] = (0,external_react_.useState)({
        status: false,
        key: ""
    });
    const handleToggle = (key)=>{
        if (isActive.key === key) {
            setIsActive({
                status: false
            });
        } else {
            setIsActive({
                status: true,
                key
            });
        }
    };
    let domNode = outsideClick(()=>{
        setIsActive({
            status: false
        });
    });
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: isToggled ? "mobile-header-active mobile-header-wrapper-style sidebar-visible" : "mobile-header-active mobile-header-wrapper-style",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "mobile-header-wrapper-inner",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "mobile-header-top",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "mobile-header-logo",
                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/index",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                            src: "/assets/imgs/theme/logo.svg",
                                            alt: "logo"
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "mobile-menu-close close-style-wrap close-style-position-inherit",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                                    className: "close-style search-close",
                                    onClick: toggleClick,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            className: "icon-top"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            className: "icon-bottom"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "mobile-header-content-area",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "mobile-search search-style-3 mobile-header-border",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("form", {
                                    action: "#",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("input", {
                                            type: "text",
                                            placeholder: "Search for items…"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("button", {
                                            type: "submit",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                className: "fi-rs-search"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "mobile-menu-wrap mobile-header-border",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "main-categori-wrap mobile-header-border",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                href: "#",
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                    className: "categori-button-active-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "fi-rs-apps"
                                                        }),
                                                        " Browse Categories"
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "categori-dropdown-wrap categori-dropdown-active-small",
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/products/shop-grid-right",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                            className: "CoderXpoint-font-dress"
                                                                        }),
                                                                        "Women's Clothing"
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/products/shop-grid-right",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                            className: "CoderXpoint-font-tshirt"
                                                                        }),
                                                                        "Men's Clothing"
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                            children: [
                                                                " ",
                                                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                    href: "/products/shop-grid-right",
                                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                                className: "CoderXpoint-font-smartphone"
                                                                            }),
                                                                            " Cellphones"
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/products/shop-grid-right",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                            className: "CoderXpoint-font-desktop"
                                                                        }),
                                                                        "Computer & Office"
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/products/shop-grid-right",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                            className: "CoderXpoint-font-cpu"
                                                                        }),
                                                                        "Consumer Electronics"
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/products/shop-grid-right",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                            className: "CoderXpoint-font-home"
                                                                        }),
                                                                        "Home & Garden"
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/products/shop-grid-right",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                            className: "CoderXpoint-font-high-heels"
                                                                        }),
                                                                        "Shoes"
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/products/shop-grid-right",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                            className: "CoderXpoint-font-teddy-bear"
                                                                        }),
                                                                        "Mother & Kids"
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: "/products/shop-grid-right",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                            className: "CoderXpoint-font-kite"
                                                                        }),
                                                                        "Outdoor fun"
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("nav", {
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                            className: "mobile-menu",
                                            ref: domNode,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                    className: isActive.key == 1 ? "menu-item-has-children active" : "menu-item-has-children",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "menu-expand",
                                                            onClick: ()=>handleToggle(1),
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                className: "fi-rs-angle-small-down"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/index",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                children: "Home"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                            className: isActive.key == 1 ? "dropdown" : "d-none",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/index",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Home 1"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/index-2",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Home 2"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/index-3",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Home 3"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/index-4",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Home 4"
                                                                        })
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                    className: isActive.key == 2 ? "menu-item-has-children active" : "menu-item-has-children",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "menu-expand",
                                                            onClick: ()=>handleToggle(2),
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                className: "fi-rs-angle-small-down"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/products/shop-grid-right",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                children: "shop"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                            className: isActive.key == 2 ? "dropdown" : "d-none",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/products/shop-grid-right",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop Grid – Right Sidebar"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/products/products",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop Grid – Left Sidebar"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/products/shop-list-right",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop List – Right Sidebar"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/products/shop-list-left",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop List – Left Sidebar"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/products/shop-fullwidth",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop - Wide"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/shop-filter",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop – Filter"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/shop-wishlist",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop – Wishlist"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/shop-cart",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop – Cart"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/shop-checkout",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop – Checkout"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/shop-compare",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Shop – Compare"
                                                                        })
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                    className: isActive.key == 3 ? "menu-item-has-children active" : "menu-item-has-children",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "menu-expand",
                                                            onClick: ()=>handleToggle(3),
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                className: "fi-rs-angle-small-down"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                children: "Mega menu"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                            className: isActive.key == 3 ? "dropdown" : "d-none",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                    className: "menu-item-has-children",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "menu-expand"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                            href: "#",
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                children: "Women's Fashion"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                            className: "dropdown",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Dresses"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Blouses & Shirts"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Hoodies & Sweatshirts"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Women's Sets"
                                                                                        })
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                    className: "menu-item-has-children",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "menu-expand"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                            href: "#",
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                children: "Men's Fashion"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                            className: "dropdown",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Jackets"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Casual Faux Leather"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Genuine Leather"
                                                                                        })
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                    className: "menu-item-has-children",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "menu-expand"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                            href: "#",
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                children: "Technology"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                            className: "dropdown",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Gaming Laptops"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Ultraslim Laptops"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Tablets"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Laptop Accessories"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/products/shop-grid-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Tablet Accessories"
                                                                                        })
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                    className: isActive.key == 4 ? "menu-item-has-children active" : "menu-item-has-children",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "menu-expand",
                                                            onClick: ()=>handleToggle(4),
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                className: "fi-rs-angle-small-down"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/blog-category-fullwidth",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                children: "Blog"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                            className: isActive.key == 4 ? "dropdown" : "d-none",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/blog-category-grid",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Blog Category Grid"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/blog-category-list",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Blog Category List"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/blog-category-big",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Blog Category Big"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/blog-category-fullwidth",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Blog Category Wide"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                                    className: "menu-item-has-children",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            className: "menu-expand"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                            href: "#",
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                children: "Single Product Layout"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                                            className: "dropdown",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/blog-post-left",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Left Sidebar"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/blog-post-right",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "Right Sidebar"
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                        href: "/blog-post-fullwidth",
                                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                                            children: "No Sidebar"
                                                                                        })
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                    className: isActive.key == 5 ? "menu-item-has-children active" : "menu-item-has-children",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "menu-expand",
                                                            onClick: ()=>handleToggle(5),
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                className: "fi-rs-angle-small-down"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                children: "Pages"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                            className: isActive.key == 5 ? "dropdown" : "d-none",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/page-about",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "About Us"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/page-contact",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Contact"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/page-account",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "My Account"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/page-login-register",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "login/register"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/page-purchase-guide",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Purchase Guide"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/page-privacy-policy",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Privacy Policy"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/page-terms",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Terms of Service"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "/page-404",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "404 Page"
                                                                        })
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                    className: isActive.key == 6 ? "menu-item-has-children active" : "menu-item-has-children",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "menu-expand",
                                                            onClick: ()=>handleToggle(6),
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                className: "fi-rs-angle-small-down"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                children: "Language"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                            className: isActive.key == 6 ? "dropdown" : "d-none",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "#",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "English"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "#",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "French"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "#",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "German"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                        href: "#",
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                            children: "Spanish"
                                                                        })
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "mobile-header-info-wrap mobile-header-border",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: "single-mobile-header-info mt-30",
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/page-contact",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                children: " Our location "
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: "single-mobile-header-info",
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/page-login-register",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                children: "Log In / Sign Up "
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: "single-mobile-header-info",
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "#",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                children: "(+01) - 2345 - 6789 "
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "mobile-social-icon",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                        className: "mb-15 text-grey-4",
                                        children: "Follow Us"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                src: "/assets/imgs/theme/icons/icon-facebook.svg",
                                                alt: ""
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                src: "/assets/imgs/theme/icons/icon-twitter.svg",
                                                alt: ""
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                src: "/assets/imgs/theme/icons/icon-instagram.svg",
                                                alt: ""
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                src: "/assets/imgs/theme/icons/icon-pinterest.svg",
                                                alt: ""
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                src: "/assets/imgs/theme/icons/icon-youtube.svg",
                                                alt: ""
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const layout_MobileMenu = (MobileMenu);

;// CONCATENATED MODULE: ./components/layout/Layout.js







const Layout = ({ children, parent, sub, subChild, noBreadcrumb, headerStyle })=>{
    const [isToggled, setToggled] = (0,external_react_.useState)(false);
    const toggleClick = ()=>{
        setToggled(!isToggled);
        isToggled ? document.querySelector("body").classList.remove("mobile-menu-active") : document.querySelector("body").classList.add("mobile-menu-active");
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("title", {
                        children: "CoderXpoint - CoderXpoint Template"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("style", {
                        children: "@import url('https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&family=Spartan:wght@300;400;500;600;700&display=swap');"
                    })
                ]
            }),
            isToggled && /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "body-overlay-1",
                onClick: toggleClick
            }),
            /*#__PURE__*/ jsx_runtime.jsx(layout_Header, {
                headerStyle: headerStyle,
                isToggled: isToggled,
                toggleClick: toggleClick
            }),
            /*#__PURE__*/ jsx_runtime.jsx(layout_MobileMenu, {
                isToggled: isToggled,
                toggleClick: toggleClick
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("main", {
                className: "main",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx(layout_Breadcrumb, {
                        parent: parent,
                        sub: sub,
                        subChild: subChild,
                        noBreadcrumb: noBreadcrumb
                    }),
                    children
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx(layout_Footer, {})
        ]
    });
};
/* harmony default export */ const layout_Layout = (Layout);


/***/ })

};
;