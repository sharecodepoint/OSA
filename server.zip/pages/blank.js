
import Layout from '../components/layout/Layout';

function Test() {
    return (
        <>
            <Layout parent="Home" sub="Pages" subChild="About">
                
            </Layout>
        </>
    );
}

export default Test;
